// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "messageHandlers": {
    "epilogue": function anonymous(
) {
var resultJson = study.options.datastore.exportJson();
jatos.submitResultData(resultJson, jatos.startNextComponent);
}
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.html.Screen",
      "files": {},
      "responses": {
        "click button": "continue"
      },
      "parameters": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
window.response = [];
window.cr = "";
}
      },
      "title": "Welcome\u002FInfo Screen",
      "content": "\u003C!DOCTYPE html\u003E\r\n\u003Chtml lang=\"en\"\u003E\r\n\u003Chead\u003E\r\n    \u003Cmeta charset=\"UTF-8\"\u003E\r\n    \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u003E\r\n    \u003Ctitle\u003EPhoneme Perception Test Instructions\u003C\u002Ftitle\u003E\r\n    \u003Cstyle\u003E\r\n        body {\r\n            font-family: Arial, sans-serif;\r\n            margin: auto;\r\n            text-align: center;\r\n        }\r\n        .button {\r\n            padding: 15px 25px;\r\n            margin-top: 20px;\r\n            font-size: 18px;\r\n            background-color: #4CAF50;\r\n            color: white;\r\n            border: none;\r\n            border-radius: 5px;\r\n            cursor: pointer;\r\n        }\r\n        .button:hover {\r\n            background-color: #45a049;\r\n        }\r\n    \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n\r\n    \u003Ch1\u003EPhoneme Perception Test Instructions\u003C\u002Fh1\u003E\r\n    \u003Cp\u003EWelcome to the phoneme perception test! Please read the following instructions carefully before starting the test.\u003C\u002Fp\u003E\r\n\r\n    \u003Ch2\u003EInstructions:\u003C\u002Fh2\u003E\r\n      \u003Cdiv style=\"text-align: center;\"\u003E\r\n          \u003Cp\u003EEnsure you are in a quiet environment and use headphones for better sound quality.\u003C\u002Fp\u003E\r\n          \u003Cp\u003EIn each trial you will be presented with a pair of Danish words. You will hear each word \u003Cstrong\u003EONCE\u003C\u002Fstrong\u003E.\u003C\u002Fp\u003E\r\n          \u003Cp\u003EThe words will play automatically and you will have to decide if they are \u003Cstrong\u003Ethe same\u003C\u002Fstrong\u003E or \u003Cstrong\u003Edifferent\u003C\u002Fstrong\u003E sounds.\u003C\u002Fp\u003E\r\n          \u003Cp\u003ERepeat this process for each pair of words until the test is complete.\u003C\u002Fp\u003E\r\n          \u003Cp\u003EThe duration of the test is approximately 6 minutes.\u003C\u002Fp\u003E\r\n          \u003Cp\u003EYou will first be presented with three \u003Cstrong\u003Emock trials\u003C\u002Fstrong\u003E so that you can test the sound.\u003C\u002Fp\u003E\r\n      \u003C\u002Fdiv\u003E\r\n\r\n\r\n    \u003Cp\u003EWhen you're ready, click the button below to start the test.\u003C\u002Fp\u003E\r\n    🤗\r\n\r\n\u003Cfooter\u003E\r\n    \r\n\u003Cbutton class=\"button\" style=\"width: 300px; \"\u003E\r\n    Continue to Mock Trial\r\n\u003C\u002Fbutton\u003E\r\n\u003C\u002Ffooter\u003E\r\n\r\n\u003C\u002Fbody\u003E\r\n\u003C\u002Fhtml\u003E\r\n"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "audioA": "skæl1.mp3",
          "audioB": "skæl2.mp3"
        },
        {
          "audioA": "mølle1.mp3",
          "audioB": "mulle2.mp3"
        },
        {
          "audioA": "fisk1.mp3",
          "audioB": "fæsk2.mp3"
        }
      ],
      "sample": {
        "mode": "draw-shuffle"
      },
      "files": {
        "ben1.mp3": "embedded\u002Fbedea72a72157abf00033ce4051adfd5dd9eb32569a6886f91556b65906d82b8.mp3",
        "ben2.mp3": "embedded\u002F724c1604b7beb2855badf2e59f26d21eb8f7ae56729cbded70a2487bafa0c3cb.mp3",
        "bøn2.mp3": "embedded\u002F595c0c871a80772b2edf7f5f7f25967ef3fbf6a0d4f2d8fba675a1c013cd3263.mp3",
        "fæsk2.mp3": "embedded\u002F0375b97f45d672ff66f724538888c8f88145b02925b70937f35ff6f6d822cf0d.mp3",
        "fisk1.mp3": "embedded\u002F971415293654ef8f772b2ab2412878d00e050bdc8e719603b042b69a30c5d267.mp3",
        "ful1.mp3": "embedded\u002Fc773c53049586c168bd019bc231a2659a928c5a836bcc5c965102ec81c7d7e17.mp3",
        "ful2.mp3": "embedded\u002F2f1abe8c0c8eef3aa2a14cde75dd87a3609a962d92ac0d748abad9a594b17fb7.mp3",
        "fyl2.mp3": "embedded\u002F28e21fe41893d64eeda77cd0780e6cb53816d37d27ba0f54202310df63b392a4.mp3",
        "grå1.mp3": "embedded\u002F733a60d07ce200a6ea6ea7fb10fffab53aad5dbeb50624b9b11bf692c5d7af87.mp3",
        "grå2.mp3": "embedded\u002F85a3270abc2c5ba265ec5398385fa6bcf1a71ac323138bc618ca24dd56fdc10d.mp3",
        "kæt2.mp3": "embedded\u002Ff46951271c6baf893d9f60e30cd5c6a0a4c7e58f256a517c46a25e06775e714e.mp3",
        "kat1.mp3": "embedded\u002F8b8db1e93248be1609e2cbaa29b3945288de832365ea8c9a70e7b05a520360a0.mp3",
        "kat2.mp3": "embedded\u002F322c167257c1fafcd117ae9c52cf739ba3a65c2808f4ef8876548cfb27ecb719.mp3",
        "los2.mp3": "embedded\u002F7d95e93995828719ddec193d9dc62bd04198d0b4e1ff0af57d2d48f0cfc79d01.mp3",
        "lys1.mp3": "embedded\u002F31614645d7c4c15f9b18e0ea202755fa3b68b04d91acf3ed9409e9528ce4da9a.mp3",
        "lys2.mp3": "embedded\u002F11a424a8f0ab13552d4c70687d701324712eba118b74b92728dedc577ff0aa0f.mp3",
        "mæt1.mp3": "embedded\u002F9d0e681c840f0eab3721c04a79cb54d0f4ec3357fedad206340602c8b0ddd396.mp3",
        "mæt2.mp3": "embedded\u002Ff15e73a2de1b2113cfcc0b4ae7c25d2910b8c2f62cc65004cd1f4e17332fdd5f.mp3",
        "nø1.mp3": "embedded\u002Fa2f4388a2a7e2038c82f9f914fe3c5f877ac9469c467b4d029a663d6324a8a35.mp3",
        "nø2.mp3": "embedded\u002F4fcd5408da4406faaa9aefe75bfde674cc780b5f962d69b96f47290894b50eb7.mp3",
        "nu2.mp3": "embedded\u002Fdfa8737ba34895ff7185dd5be0f8b54d5f1398d226d016710237526a50b82597.mp3",
        "sæt2.mp3": "embedded\u002Fcaf51ded1d41a1586e05f98f4297483dd33c5b0865de55ea3fc329653c616955.mp3",
        "set1.mp3": "embedded\u002F28134c35b1c77591d0b44cdc6e3e15c9b5301372dc6fb5e885012cc32ccdbc7d.mp3",
        "søn2.mp3": "embedded\u002F0af3da16161c3828520c8319a4a25e72e4528c1f670be35c05dda89bcfa08457.mp3",
        "syn1.mp3": "embedded\u002Fd452ee999442c644bdb4bc91372b47c2da55c801711ba21ca1ac44488e810ad6.mp3",
        "dør1.mp3": "embedded\u002Fcdbb034df6e0ca4ce3058910f71fe28127ebcf0b9c6eda112c90a75fafccfbb7.mp3",
        "dør2.mp3": "embedded\u002F5769477b1373ce6c4df82db9e910745939ace161373a0a4e3738914b784b370c.mp3",
        "løg1.mp3": "embedded\u002F79dff02e9f54f92292e9d544025d80b9f1ef5ddc2980f4f5b899d82504b253b4.mp3",
        "ly2.mp3": "embedded\u002F494bc25fea2bf61a37a112913b3a9c02394cfd071f6d8cfa77c757a6eb00035f.mp3",
        "møl1.mp3": "embedded\u002Fdd34df4f04b23d2a8787a84980e4bd34602b760b44ac687113b0be6e84574899.mp3",
        "møl2.mp3": "embedded\u002Ff84567647c836eb41d348ba01d1cf6a0d11ce3b0f3a9585dfacd9652ba1e7e1d.mp3",
        "mølle1.mp3": "embedded\u002F858f9e9dc3a093b56c140640128b390d8af533a618a7326fd94d1c98010167ee.mp3",
        "mulle2.mp3": "embedded\u002Fd5c642607acd6ff8b24dc965211e38131d437159ba29f4577bab2f629d373e22.mp3",
        "rær2.mp3": "embedded\u002F3020f1c62448e1d3a724af487be6fdad18e0a40e127f44a8903b707f03a76099.mp3",
        "rød1.mp3": "embedded\u002F30df70dd314ee8e2bf886c0bb28a59ad194a070ec813ee793c109519d15830d9.mp3",
        "rød2.mp3": "embedded\u002F5ec0244fec9b85479e826b3de9f2e80a4a3dfc17306c13058f28fd42eccaaacc.mp3",
        "rør1.mp3": "embedded\u002F85e5e9778a2de346d9eac7a2caccae5d589c334b03c9d02aac55ea7fdffa5b69.mp3",
        "ryd2.mp3": "embedded\u002F603564e6dcda5f8b46402f7277e7726dbcdf685a403bec20d394e2a285b1da9b.mp3",
        "skæl1.mp3": "embedded\u002F39fa7c677aa9d4d810a7c292db4e7c802ff28c2ce1fa3402effc24b2fca06257.mp3",
        "skæl2.mp3": "embedded\u002F13932b60fadb8be6a332b360444433d4441948e6c5b04adde03c54094525b06a.mp3",
        "sø1.mp3": "embedded\u002F42be682e4b3d25e61ba277c7d1229cc33731c9e2be483d27f727b452b3f532d8.mp3",
        "sød2.mp3": "embedded\u002F79bd0d8bb48f49180d47272b6d1561629fdcea7a38cb4984304a4bd680142107.mp3",
        "su2.mp3": "embedded\u002F42cfb7d9bc5c7b70ce48fe2fb23418d3f6646ca25d32b952cde2109f6e51bad6.mp3",
        "syd1.mp3": "embedded\u002F50532bdac13b068a8ee9cae13d9b72f6773f8821dd668e1e1464a6e5ec9e7441.mp3",
        "syr1.mp3": "embedded\u002Fb3c374985e394a832b71378a4c447b7dd80e89645d7a43dd39afe2fc9d66f5ea.mp3",
        "syr2.mp3": "embedded\u002F046d6f1d684c0bd62f2c114c3fb17d7c630b820336c4094503d9afeec646499e.mp3",
        "tæt2.mp3": "embedded\u002Fda65a3141561ccbbbd8a6502c6e567a960ce9410eb315ec068925be71e73e58e.mp3",
        "tat1.mp3": "embedded\u002F9cae75fe2798ddf7cf4269ed8aefec3ab905af4fd08bfea37106d91b904c9918.mp3",
        "væg1.mp3": "embedded\u002Fb3293bda1a4d34bee11faff6590356549612bd1ced0a5344298315b093fcb26b.mp3",
        "vægt2.mp3": "embedded\u002F4aa4fb83292115d7edc2ad217e41abf3e65717ac278b6f714de1dec59fbc4466.mp3",
        "fær2.mp3": "embedded\u002F2a620d5742d3a1f510f74507891d87e978ab077f5237a984151faa39f10c1947.mp3",
        "før1.mp3": "embedded\u002Fb09e735d220e1d0be46005c2587da761d5abac09d32ada1098855d0a24d87dcb.mp3",
        "let2.mp3": "embedded\u002F2e503cbf004f90094cac377de8ad00032005039ec13f3500a777ed7ea4f6e18f.mp3",
        "lidt1.mp3": "embedded\u002F0f2cb539e044333ebe42ab5eda37db8ac2768dffbc3534c1de7a9ee32712df64.mp3",
        "pen2.mp3": "embedded\u002F01a6ab07127bbd84d464f01fe1547a5c5a1ea3b6d5ddfbae5a98f1a83be86fa5.mp3",
        "ven1.mp3": "embedded\u002F89926a6fc9abdc5c8753a85937768de57c91eb11ecb9e2b7a8d607f8cd43ef98.mp3",
        "bil2.mp3": "embedded\u002F4643903ea121ee37357c24dac214c4d04a62ff875addc717dbea5fe7bc755853.mp3",
        "pil1.mp3": "embedded\u002F3bd9558c48f6d3485bb6a02f579efdc5c01ad6dbd037f8b53aba3d5914c925cb.mp3",
        "sende2.mp3": "embedded\u002F6212e282ae60a573ce7f4f8cad0b18ed5d2db93ac6a16a98c9844ba534986aac.mp3",
        "sinde1.mp3": "embedded\u002F37dafc4daba987fe31882875f0173898e45f264e9f1d04baf6b660602beddb68.mp3",
        "gul1.mp3": "embedded\u002Ff7420d491951d1db84e736cc82dc520553b1e05003a98f4ae2a77e5e0e940a1b.mp3",
        "guld2.mp3": "embedded\u002F17987fa5c382a926327ec8ea0497e886c0b4377480e0000bbc40054f02ed2edc.mp3",
        "fugl2.mp3": "embedded\u002Fab5b4b19c93c3ffa1cb41d7115161415e83c0387f26b9fb394de835f0500eb85.mp3",
        "fuld2.mp3": "embedded\u002Fea578d6f6687664d256a2c0a10c1a8fc3f00acef49e15d8ce92183ffa1b21def.mp3",
        "fuld1.mp3": "embedded\u002Fbdc4279af937118e1e271ca7f0782c0283cbddfcf9de3ecdb7b1da02545f8007.mp3",
        "røre2.mp3": "embedded\u002F07a1d72edcff78ee85adef703b6b1aef45a9a527ba4a473295c43e0a95ac3db8.mp3",
        "røre1.mp3": "embedded\u002F65ba5c34f4a8a26b7c54d8903ea4c6c6c2a5b01c9c076c99379c09ea5ec18c42.mp3",
        "lød2.mp3": "embedded\u002F1c4be1ef478fa7fa6135721bcb9738ba90d71ecb3fcde1b1d0f2669f3f91f75d.mp3"
      },
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Mock trial",
      "indexParameter": "counter",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {
          "": ""
        },
        "parameters": {},
        "messageHandlers": {},
        "title": "Sequence",
        "content": [
          {
            "type": "lab.html.Screen",
            "files": {},
            "responses": {
              "click #same": "same",
              "click #different": "different"
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Screen - Yes\u002FNo",
            "content": "\u003C!DOCTYPE html\u003E\r\n\u003Chtml lang=\"en\"\u003E\r\n\u003Chead\u003E\r\n  \u003Cmeta charset=\"UTF-8\"\u003E\r\n  \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u003E\r\n  \u003Ctitle\u003EAudio Perception Test\u003C\u002Ftitle\u003E\r\n  \u003Clink rel=\"stylesheet\" href=\"https:\u002F\u002Fcdnjs.cloudflare.com\u002Fajax\u002Flibs\u002Ffont-awesome\u002F6.0.0-beta3\u002Fcss\u002Fall.min.css\"\u003E\r\n  \u003Cstyle\u003E\r\n    \u002F* Header and trial title styles *\u002F\r\n    header, h3 {\r\n      text-align: center;\r\n    }\r\n\r\n    \u002F* Default (disabled) button style *\u002F\r\n    button {\r\n      padding: 10px 20px;\r\n      font-size: 1rem;\r\n      margin: 10px;\r\n      border: none;\r\n      border-radius: 5px;\r\n      background-color: transparent;\r\n      color: black;\r\n      cursor: not-allowed;\r\n      transition: background-color 0.3s ease;\r\n    }\r\n\r\n    \u002F* Active button styles *\u002F\r\n    .active-button {\r\n      color: white;\r\n      cursor: pointer;\r\n    }\r\n\r\n    \u002F* Specific styles for each button when active *\u002F\r\n    #same.active-button {\r\n      background-color: #4CAF50; \u002F* Green *\u002F\r\n    }\r\n    #same.active-button:hover {\r\n      background-color: #45a049; \u002F* Darker green *\u002F\r\n    }\r\n\r\n    #different.active-button {\r\n      background-color: #f44336; \u002F* Red *\u002F\r\n    }\r\n    #different.active-button:hover {\r\n      background-color: #d32f2f; \u002F* Darker red *\u002F\r\n    }\r\n\r\n    \u002F* Center content *\u002F\r\n    .content-horizontal-center {\r\n      display: flex;\r\n      justify-content: center;\r\n    }\r\n    .content-vertical-center {\r\n      align-items: center;\r\n      height: 100vh;\r\n      display: flex;\r\n      flex-direction: column;\r\n    }\r\n\r\n    \u002F* Sound icon styling *\u002F\r\n    .sound-icon {\r\n      font-size: 5rem;\r\n      color: #555;\r\n      transition: color 0.3s;\r\n    }\r\n  \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n\r\n\u003Cheader\u003E\r\n  \u003Ch2\u003EDo you hear the same word?\u003C\u002Fh2\u003E\r\n  \u003Ch3\u003EMake sure you have an audio connection\u003C\u002Fh3\u003E\r\n\u003C\u002Fheader\u003E\r\n\r\n\u003Ch3\u003E Mock trial ${this.parameters.counter + 1}\u003C\u002Fh3\u003E\r\n\r\n\u003Cmain class=\"content-horizontal-center content-vertical-center\"\u003E\r\n  \u003C!-- Sound icon in the middle of the screen --\u003E\r\n  \u003Ci class=\"fas fa-volume-up sound-icon\"\u003E\u003C\u002Fi\u003E\r\n\r\n  \u003Ctable class=\"w-l table-plain\" style=\"font-size: 1.5rem; margin-top: 30px;\"\u003E\r\n    \u003Ctr\u003E\r\n      \u003Ctd style=\"width: 50%\"\u003E\r\n        \u003Caudio id=\"audioA\" \r\n               onloadeddata=\"setTimeout(() =\u003E { \r\n                 this.play(); \r\n                 document.getElementById('same').disabled = true; \r\n                 document.getElementById('different').disabled = true; \r\n               }, 1500);\" \r\n               onended=\"setTimeout(() =\u003E document.getElementById('audioB').play(), 1000);\" \r\n               style=\"display:none;\"\u003E\r\n          \u003Csource src=\"${this.files[parameters.switch ? parameters.audioA : parameters.audioB]}\" type=\"audio\u002Fmpeg\"\u003E\r\n          Your browser does not support the audio element.\r\n        \u003C\u002Faudio\u003E\r\n      \u003C\u002Ftd\u003E\r\n      \u003Ctd style=\"width: 50%\"\u003E\r\n        \u003Caudio id=\"audioB\" \r\n               onended=\"document.getElementById('same').disabled = false; \r\n                        document.getElementById('different').disabled = false;\r\n                        document.getElementById('same').classList.add('active-button'); \r\n                        document.getElementById('different').classList.add('active-button');\" \r\n               style=\"display:none;\"\u003E\r\n          \u003Csource src=\"${this.files[parameters.switch ? parameters.audioB : parameters.audioA]}\" type=\"audio\u002Fmpeg\"\u003E\r\n          Your browser does not support the audio element.\r\n        \u003C\u002Faudio\u003E\r\n      \u003C\u002Ftd\u003E\r\n    \u003C\u002Ftr\u003E\r\n  \u003C\u002Ftable\u003E\r\n\u003C\u002Fmain\u003E\r\n\r\n\u003Cfooter style=\"text-align: center; margin-top: 20px;\"\u003E\r\n  \u003Cbutton id=\"same\" disabled\u003ESame\u003C\u002Fbutton\u003E\r\n  \u003Cbutton id=\"different\" disabled\u003EDifferent\u003C\u002Fbutton\u003E\r\n\u003C\u002Ffooter\u003E\r\n\r\n\u003C\u002Fbody\u003E\r\n\u003C\u002Fhtml\u003E\r\n",
            "correctResponse": "${parameters.audioA.replace(\u002F\\d*\\.mp3$\u002F,'') === parameters.audioB.replace(\u002F\\d*\\.mp3$\u002F,'') ? 'same' : 'different'}"
          }
        ]
      }
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "type": "text",
          "content": "\u003C!DOCTYPE html\u003E\n\u003Chtml lang=\"en\"\u003E\n\u003Chead\u003E\n    \u003Cmeta charset=\"UTF-8\"\u003E\n    \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u003E\n    \u003Ctitle\u003EMock Trial Message\u003C\u002Ftitle\u003E\n    \u003Cstyle\u003E\n        .centered-content {\n            display: flex;\n            flex-direction: column;\n            justify-content: center;\n            align-items: center;\n            height: 100vh;\n            text-align: center;\n            font-family: Arial, sans-serif;\n        }\n        .button {\n            padding: 15px 25px;\n            margin-top: 20px;\n            font-size: 18px;\n            background-color: #4CAF50;\n            color: white;\n            border: none;\n            border-radius: 5px;\n            cursor: pointer;\n        }\n        .button:hover {\n            background-color: #45a049;\n        }\n    \u003C\u002Fstyle\u003E\n\u003C\u002Fhead\u003E\n\u003Cbody\u003E\n    \u003Cdiv class=\"centered-content\"\u003E\n        \u003Cp\u003E\u003Cstrong\u003EEnd of mock trial\u003C\u002Fstrong\u003E.\u003C\u002Fp\u003E\n        \u003Cp\u003EPress \"Start the Test\" when you are ready.\u003C\u002Fp\u003E\n        \u003Cbutton class=\"button\" id=\"continue\"\u003EStart the Test\u003C\u002Fbutton\u003E\n    \u003C\u002Fdiv\u003E\n\u003C\u002Fbody\u003E\n\u003C\u002Fhtml\u003E\n"
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →continue",
      "submitButtonPosition": "hidden",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Start test"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "audioA": "ful1.mp3",
          "audioB": "ful2.mp3"
        },
        {
          "audioA": "lys1.mp3",
          "audioB": "lys2.mp3"
        },
        {
          "audioA": "mæt1.mp3",
          "audioB": "mæt2.mp3"
        },
        {
          "audioA": "kat1.mp3",
          "audioB": "kat2.mp3"
        },
        {
          "audioA": "ben1.mp3",
          "audioB": "ben2.mp3"
        },
        {
          "audioA": "grå1.mp3",
          "audioB": "grå2.mp3"
        },
        {
          "audioA": "nø1.mp3",
          "audioB": "nø2.mp3"
        },
        {
          "audioA": "ful1.mp3",
          "audioB": "fyl2.mp3"
        },
        {
          "audioA": "syn1.mp3",
          "audioB": "søn2.mp3"
        },
        {
          "audioA": "set1.mp3",
          "audioB": "sæt2.mp3"
        },
        {
          "audioA": "kat1.mp3",
          "audioB": "kæt2.mp3"
        },
        {
          "audioA": "fisk1.mp3",
          "audioB": "fæsk2.mp3"
        },
        {
          "audioA": "lys1.mp3",
          "audioB": "los2.mp3"
        },
        {
          "audioA": "ben1.mp3",
          "audioB": "bøn2.mp3"
        },
        {
          "audioA": "nø1.mp3",
          "audioB": "nu2.mp3"
        },
        {
          "audioA": "rød1.mp3",
          "audioB": "ryd2.mp3"
        },
        {
          "audioA": "mølle1.mp3",
          "audioB": "mulle2.mp3"
        },
        {
          "audioA": "syd1.mp3",
          "audioB": "sød2.mp3"
        },
        {
          "audioA": "tat1.mp3",
          "audioB": "tæt2.mp3"
        },
        {
          "audioA": "sø1.mp3",
          "audioB": "su2.mp3"
        },
        {
          "audioA": "væg1.mp3",
          "audioB": "vægt2.mp3"
        },
        {
          "audioA": "løg1.mp3",
          "audioB": "ly2.mp3"
        },
        {
          "audioA": "rør1.mp3",
          "audioB": "rær2.mp3"
        },
        {
          "audioA": "rød1.mp3",
          "audioB": "rød2.mp3"
        },
        {
          "audioA": "møl1.mp3",
          "audioB": "møl2.mp3"
        },
        {
          "audioA": "syr1.mp3",
          "audioB": "syr2.mp3"
        },
        {
          "audioA": "dør1.mp3",
          "audioB": "dør2.mp3"
        },
        {
          "audioA": "skæl1.mp3",
          "audioB": "skæl2.mp3"
        },
        {
          "audioA": "røre1.mp3",
          "audioB": "røre2.mp3"
        },
        {
          "audioA": "fuld1.mp3",
          "audioB": "fuld2.mp3"
        },
        {
          "audioA": "rød1.mp3",
          "audioB": "lød2.mp3"
        },
        {
          "audioA": "fuld1.mp3",
          "audioB": "fugl2.mp3"
        },
        {
          "audioA": "gul1.mp3",
          "audioB": "guld2.mp3"
        },
        {
          "audioA": "sinde1.mp3",
          "audioB": "sende2.mp3"
        },
        {
          "audioA": "pil1.mp3",
          "audioB": "bil2.mp3"
        },
        {
          "audioA": "ven1.mp3",
          "audioB": "pen2.mp3"
        },
        {
          "audioA": "lidt1.mp3",
          "audioB": "let2.mp3"
        },
        {
          "audioA": "før1.mp3",
          "audioB": "fær2.mp3"
        }
      ],
      "sample": {
        "mode": "draw-shuffle"
      },
      "files": {
        "ben1.mp3": "embedded\u002Fbedea72a72157abf00033ce4051adfd5dd9eb32569a6886f91556b65906d82b8.mp3",
        "ben2.mp3": "embedded\u002F724c1604b7beb2855badf2e59f26d21eb8f7ae56729cbded70a2487bafa0c3cb.mp3",
        "bøn2.mp3": "embedded\u002F595c0c871a80772b2edf7f5f7f25967ef3fbf6a0d4f2d8fba675a1c013cd3263.mp3",
        "fæsk2.mp3": "embedded\u002F0375b97f45d672ff66f724538888c8f88145b02925b70937f35ff6f6d822cf0d.mp3",
        "fisk1.mp3": "embedded\u002F971415293654ef8f772b2ab2412878d00e050bdc8e719603b042b69a30c5d267.mp3",
        "ful1.mp3": "embedded\u002Fc773c53049586c168bd019bc231a2659a928c5a836bcc5c965102ec81c7d7e17.mp3",
        "ful2.mp3": "embedded\u002F2f1abe8c0c8eef3aa2a14cde75dd87a3609a962d92ac0d748abad9a594b17fb7.mp3",
        "fyl2.mp3": "embedded\u002F28e21fe41893d64eeda77cd0780e6cb53816d37d27ba0f54202310df63b392a4.mp3",
        "grå1.mp3": "embedded\u002F733a60d07ce200a6ea6ea7fb10fffab53aad5dbeb50624b9b11bf692c5d7af87.mp3",
        "grå2.mp3": "embedded\u002F85a3270abc2c5ba265ec5398385fa6bcf1a71ac323138bc618ca24dd56fdc10d.mp3",
        "kæt2.mp3": "embedded\u002Ff46951271c6baf893d9f60e30cd5c6a0a4c7e58f256a517c46a25e06775e714e.mp3",
        "kat1.mp3": "embedded\u002F8b8db1e93248be1609e2cbaa29b3945288de832365ea8c9a70e7b05a520360a0.mp3",
        "kat2.mp3": "embedded\u002F322c167257c1fafcd117ae9c52cf739ba3a65c2808f4ef8876548cfb27ecb719.mp3",
        "los2.mp3": "embedded\u002F7d95e93995828719ddec193d9dc62bd04198d0b4e1ff0af57d2d48f0cfc79d01.mp3",
        "lys1.mp3": "embedded\u002F31614645d7c4c15f9b18e0ea202755fa3b68b04d91acf3ed9409e9528ce4da9a.mp3",
        "lys2.mp3": "embedded\u002F11a424a8f0ab13552d4c70687d701324712eba118b74b92728dedc577ff0aa0f.mp3",
        "mæt1.mp3": "embedded\u002F9d0e681c840f0eab3721c04a79cb54d0f4ec3357fedad206340602c8b0ddd396.mp3",
        "mæt2.mp3": "embedded\u002Ff15e73a2de1b2113cfcc0b4ae7c25d2910b8c2f62cc65004cd1f4e17332fdd5f.mp3",
        "nø1.mp3": "embedded\u002Fa2f4388a2a7e2038c82f9f914fe3c5f877ac9469c467b4d029a663d6324a8a35.mp3",
        "nø2.mp3": "embedded\u002F4fcd5408da4406faaa9aefe75bfde674cc780b5f962d69b96f47290894b50eb7.mp3",
        "nu2.mp3": "embedded\u002Fdfa8737ba34895ff7185dd5be0f8b54d5f1398d226d016710237526a50b82597.mp3",
        "sæt2.mp3": "embedded\u002Fcaf51ded1d41a1586e05f98f4297483dd33c5b0865de55ea3fc329653c616955.mp3",
        "set1.mp3": "embedded\u002F28134c35b1c77591d0b44cdc6e3e15c9b5301372dc6fb5e885012cc32ccdbc7d.mp3",
        "søn2.mp3": "embedded\u002F0af3da16161c3828520c8319a4a25e72e4528c1f670be35c05dda89bcfa08457.mp3",
        "syn1.mp3": "embedded\u002Fd452ee999442c644bdb4bc91372b47c2da55c801711ba21ca1ac44488e810ad6.mp3",
        "dør1.mp3": "embedded\u002Fcdbb034df6e0ca4ce3058910f71fe28127ebcf0b9c6eda112c90a75fafccfbb7.mp3",
        "dør2.mp3": "embedded\u002F5769477b1373ce6c4df82db9e910745939ace161373a0a4e3738914b784b370c.mp3",
        "løg1.mp3": "embedded\u002F79dff02e9f54f92292e9d544025d80b9f1ef5ddc2980f4f5b899d82504b253b4.mp3",
        "ly2.mp3": "embedded\u002F494bc25fea2bf61a37a112913b3a9c02394cfd071f6d8cfa77c757a6eb00035f.mp3",
        "møl1.mp3": "embedded\u002Fdd34df4f04b23d2a8787a84980e4bd34602b760b44ac687113b0be6e84574899.mp3",
        "møl2.mp3": "embedded\u002Ff84567647c836eb41d348ba01d1cf6a0d11ce3b0f3a9585dfacd9652ba1e7e1d.mp3",
        "mølle1.mp3": "embedded\u002F858f9e9dc3a093b56c140640128b390d8af533a618a7326fd94d1c98010167ee.mp3",
        "mulle2.mp3": "embedded\u002Fd5c642607acd6ff8b24dc965211e38131d437159ba29f4577bab2f629d373e22.mp3",
        "rær2.mp3": "embedded\u002F3020f1c62448e1d3a724af487be6fdad18e0a40e127f44a8903b707f03a76099.mp3",
        "rød1.mp3": "embedded\u002F30df70dd314ee8e2bf886c0bb28a59ad194a070ec813ee793c109519d15830d9.mp3",
        "rød2.mp3": "embedded\u002F5ec0244fec9b85479e826b3de9f2e80a4a3dfc17306c13058f28fd42eccaaacc.mp3",
        "rør1.mp3": "embedded\u002F85e5e9778a2de346d9eac7a2caccae5d589c334b03c9d02aac55ea7fdffa5b69.mp3",
        "ryd2.mp3": "embedded\u002F603564e6dcda5f8b46402f7277e7726dbcdf685a403bec20d394e2a285b1da9b.mp3",
        "skæl1.mp3": "embedded\u002F39fa7c677aa9d4d810a7c292db4e7c802ff28c2ce1fa3402effc24b2fca06257.mp3",
        "skæl2.mp3": "embedded\u002F13932b60fadb8be6a332b360444433d4441948e6c5b04adde03c54094525b06a.mp3",
        "sø1.mp3": "embedded\u002F42be682e4b3d25e61ba277c7d1229cc33731c9e2be483d27f727b452b3f532d8.mp3",
        "sød2.mp3": "embedded\u002F79bd0d8bb48f49180d47272b6d1561629fdcea7a38cb4984304a4bd680142107.mp3",
        "su2.mp3": "embedded\u002F42cfb7d9bc5c7b70ce48fe2fb23418d3f6646ca25d32b952cde2109f6e51bad6.mp3",
        "syd1.mp3": "embedded\u002F50532bdac13b068a8ee9cae13d9b72f6773f8821dd668e1e1464a6e5ec9e7441.mp3",
        "syr1.mp3": "embedded\u002Fb3c374985e394a832b71378a4c447b7dd80e89645d7a43dd39afe2fc9d66f5ea.mp3",
        "syr2.mp3": "embedded\u002F046d6f1d684c0bd62f2c114c3fb17d7c630b820336c4094503d9afeec646499e.mp3",
        "tæt2.mp3": "embedded\u002Fda65a3141561ccbbbd8a6502c6e567a960ce9410eb315ec068925be71e73e58e.mp3",
        "tat1.mp3": "embedded\u002F9cae75fe2798ddf7cf4269ed8aefec3ab905af4fd08bfea37106d91b904c9918.mp3",
        "væg1.mp3": "embedded\u002Fb3293bda1a4d34bee11faff6590356549612bd1ced0a5344298315b093fcb26b.mp3",
        "vægt2.mp3": "embedded\u002F4aa4fb83292115d7edc2ad217e41abf3e65717ac278b6f714de1dec59fbc4466.mp3",
        "fuld2.mp3": "embedded\u002Fea578d6f6687664d256a2c0a10c1a8fc3f00acef49e15d8ce92183ffa1b21def.mp3",
        "fuld1.mp3": "embedded\u002Fbdc4279af937118e1e271ca7f0782c0283cbddfcf9de3ecdb7b1da02545f8007.mp3",
        "røre2.mp3": "embedded\u002F07a1d72edcff78ee85adef703b6b1aef45a9a527ba4a473295c43e0a95ac3db8.mp3",
        "røre1.mp3": "embedded\u002F65ba5c34f4a8a26b7c54d8903ea4c6c6c2a5b01c9c076c99379c09ea5ec18c42.mp3",
        "gul1.mp3": "embedded\u002Ff7420d491951d1db84e736cc82dc520553b1e05003a98f4ae2a77e5e0e940a1b.mp3",
        "guld2.mp3": "embedded\u002F17987fa5c382a926327ec8ea0497e886c0b4377480e0000bbc40054f02ed2edc.mp3",
        "fugl2.mp3": "embedded\u002Fab5b4b19c93c3ffa1cb41d7115161415e83c0387f26b9fb394de835f0500eb85.mp3",
        "lød2.mp3": "embedded\u002F1c4be1ef478fa7fa6135721bcb9738ba90d71ecb3fcde1b1d0f2669f3f91f75d.mp3",
        "fær2.mp3": "embedded\u002F2a620d5742d3a1f510f74507891d87e978ab077f5237a984151faa39f10c1947.mp3",
        "før1.mp3": "embedded\u002Fb09e735d220e1d0be46005c2587da761d5abac09d32ada1098855d0a24d87dcb.mp3",
        "let2.mp3": "embedded\u002F2e503cbf004f90094cac377de8ad00032005039ec13f3500a777ed7ea4f6e18f.mp3",
        "lidt1.mp3": "embedded\u002F0f2cb539e044333ebe42ab5eda37db8ac2768dffbc3534c1de7a9ee32712df64.mp3",
        "pen2.mp3": "embedded\u002F01a6ab07127bbd84d464f01fe1547a5c5a1ea3b6d5ddfbae5a98f1a83be86fa5.mp3",
        "ven1.mp3": "embedded\u002F89926a6fc9abdc5c8753a85937768de57c91eb11ecb9e2b7a8d607f8cd43ef98.mp3",
        "bil2.mp3": "embedded\u002F4643903ea121ee37357c24dac214c4d04a62ff875addc717dbea5fe7bc755853.mp3",
        "pil1.mp3": "embedded\u002F3bd9558c48f6d3485bb6a02f579efdc5c01ad6dbd037f8b53aba3d5914c925cb.mp3",
        "sende2.mp3": "embedded\u002F6212e282ae60a573ce7f4f8cad0b18ed5d2db93ac6a16a98c9844ba534986aac.mp3",
        "sinde1.mp3": "embedded\u002F37dafc4daba987fe31882875f0173898e45f264e9f1d04baf6b660602beddb68.mp3"
      },
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Yes\u002FNo test",
      "indexParameter": "counter",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {
          "": ""
        },
        "parameters": {},
        "messageHandlers": {},
        "title": "Sequence",
        "content": [
          {
            "type": "lab.html.Screen",
            "files": {},
            "responses": {
              "click #same": "same",
              "click #different": "different"
            },
            "parameters": {},
            "messageHandlers": {
              "run": function anonymous(
) {
function recordResponse(participantResponse) {
  const correctResponse = document.getElementById('correctResponse').value;
  const isCorrect = participantResponse === correctResponse;
  const A = document.getElementById('A').value;
  const B = document.getElementById('B').value;
  const trialData = {
      participantResponse: participantResponse,
      correctResponse: correctResponse,
      isCorrect: isCorrect,
      word1: A,
      word2: B
  };
  console.log(trialData)
  window.response.push(trialData);
}
document.getElementById('same').addEventListener('click', () => recordResponse("same"));
document.getElementById('different').addEventListener('click', () => recordResponse("different"));

}
            },
            "title": "Screen - Yes\u002FNo",
            "content": "\u003C!DOCTYPE html\u003E\r\n\u003Chtml lang=\"en\"\u003E\r\n\u003Chead\u003E\r\n  \u003Cmeta charset=\"UTF-8\"\u003E\r\n  \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u003E\r\n  \u003Ctitle\u003EAudio Perception Test\u003C\u002Ftitle\u003E\r\n    \u003Clink rel=\"stylesheet\" href=\"https:\u002F\u002Fcdnjs.cloudflare.com\u002Fajax\u002Flibs\u002Ffont-awesome\u002F6.0.0-beta3\u002Fcss\u002Fall.min.css\"\u003E\r\n  \u003Cstyle\u003E\r\n    \u002F* Header and trial title styles *\u002F\r\n    header, h3 {\r\n      text-align: center;\r\n    }\r\n\r\n    \u002F* Default (disabled) button style *\u002F\r\n    button {\r\n      padding: 10px 20px;\r\n      font-size: 1rem;\r\n      margin: 10px;\r\n      border: none;\r\n      border-radius: 5px;\r\n      background-color: transparent;\r\n      color: black;\r\n      cursor: not-allowed;\r\n      transition: background-color 0.3s ease;\r\n    }\r\n\r\n    \u002F* Active button styles *\u002F\r\n    .active-button {\r\n      color: white;\r\n      cursor: pointer;\r\n    }\r\n\r\n    \u002F* Specific styles for each button when active *\u002F\r\n    #same.active-button {\r\n      background-color: #4CAF50; \u002F* Green *\u002F\r\n    }\r\n    #same.active-button:hover {\r\n      background-color: #45a049; \u002F* Darker green *\u002F\r\n    }\r\n\r\n    #different.active-button {\r\n      background-color: #f44336; \u002F* Red *\u002F\r\n    }\r\n    #different.active-button:hover {\r\n      background-color: #d32f2f; \u002F* Darker red *\u002F\r\n    }\r\n\r\n    \u002F* Center content *\u002F\r\n    .content-horizontal-center {\r\n      display: flex;\r\n      justify-content: center;\r\n    }\r\n    .content-vertical-center {\r\n      align-items: center;\r\n      height: 100vh;\r\n      display: flex;\r\n      flex-direction: column;\r\n    }\r\n    .sound-icon {\r\n      font-size: 5rem;\r\n      color: #555;\r\n      transition: color 0.3s;\r\n    }\r\n    \u002F* Hidden input field *\u002F\r\n    .hidden-input {\r\n      display: none;\r\n    }\r\n  \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n\r\n\u003Cheader\u003E\r\n  \u003Ch2\u003EDo you hear the same word?\u003C\u002Fh2\u003E\r\n\u003C\u002Fheader\u003E\r\n\r\n\u003Ch3\u003ETrial ${this.parameters.counter + 1}\u003C\u002Fh3\u003E\r\n\r\n\u003Cmain class=\"content-horizontal-center content-vertical-center\"\u003E\r\n  \u003Ci class=\"fas fa-volume-up sound-icon\"\u003E\u003C\u002Fi\u003E\r\n\r\n  \u003Ctable class=\"w-l table-plain\" style=\"font-size: 1.5rem\"\u003E\r\n    \u003Ctr\u003E\r\n      \u003Ctd style=\"width: 50%\"\u003E\r\n        \u003Caudio id=\"audioA\"\r\n               onloadeddata=\"setTimeout(() =\u003E { \r\n                 this.play(); \r\n                 document.getElementById('same').disabled = true; \r\n                 document.getElementById('different').disabled = true; \r\n               }, 1500);\" \r\n               onended=\"setTimeout(() =\u003E document.getElementById('audioB').play(), 1000);\" \r\n               style=\"display:none;\"\u003E\r\n          \u003Csource src=\"${this.files[parameters.audioA]}\" type=\"audio\u002Fmpeg\"\u003E\r\n          Your browser does not support the audio element.\r\n        \u003C\u002Faudio\u003E\r\n      \u003C\u002Ftd\u003E\r\n      \u003Ctd style=\"width: 50%\"\u003E\r\n        \u003Caudio id=\"audioB\" \r\n               onended=\"document.getElementById('same').disabled = false; \r\n                        document.getElementById('different').disabled = false;\r\n                        document.getElementById('same').classList.add('active-button'); \r\n                        document.getElementById('different').classList.add('active-button');\" \r\n               style=\"display:none;\"\u003E\r\n          \u003Csource src=\"${this.files[parameters.audioB]}\" type=\"audio\u002Fmpeg\"\u003E\r\n          Your browser does not support the audio element.\r\n        \u003C\u002Faudio\u003E\r\n      \u003C\u002Ftd\u003E\r\n    \u003C\u002Ftr\u003E\r\n  \u003C\u002Ftable\u003E\r\n\u003C\u002Fmain\u003E\r\n\r\n\u003C!-- Hidden input to store the correct response --\u003E\r\n\u003Cinput type=\"hidden\" id=\"correctResponse\" class=\"hidden-input\" value=\"${parameters.audioA.replace(\u002F\\d*\\.mp3$\u002F, '') === parameters.audioB.replace(\u002F\\d*\\.mp3$\u002F, '') ? 'same' : 'different'}\"\u003E\r\n\r\n\u003Cinput type=\"hidden\" id=\"A\" class=\"hidden-input\" value=\"${parameters.audioA.replace(\u002F\\d*\\.mp3$\u002F, '')}\"\u003E\r\n\r\n\u003Cinput type=\"hidden\" id=\"B\" class=\"hidden-input\" value=\"${parameters.audioB.replace(\u002F\\d*\\.mp3$\u002F, '')}\"\u003E\r\n\r\n\r\n\u003Cfooter style=\"text-align: center; margin-top: 20px;\"\u003E\r\n  \u003Cbutton id=\"same\" disabled\u003ESame\u003C\u002Fbutton\u003E\r\n  \u003Cbutton id=\"different\" disabled\u003EDifferent\u003C\u002Fbutton\u003E\r\n\u003C\u002Ffooter\u003E\r\n\r\n\u003C\u002Fbody\u003E\r\n\u003C\u002Fhtml\u003E\r\n",
            "correctResponse": "${parameters.audioA.replace(\u002F\\d*\\.mp3$\u002F,'') === parameters.audioB.replace(\u002F\\d*\\.mp3$\u002F,'') ? 'same' : 'different'}"
          },
          {
            "type": "lab.html.Page",
            "items": [
              {
                "type": "text",
                "content": "\u003C!DOCTYPE html\u003E\n\u003Chtml lang=\"en\"\u003E\n\u003Chead\u003E\n  \u003Cmeta charset=\"UTF-8\"\u003E\n  \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u003E\n  \u003Ctitle\u003EBreak Screen\u003C\u002Ftitle\u003E\n  \u003Cstyle\u003E\n    body {\n      display: flex;\n      justify-content: center;\n      align-items: center;\n      height: 100vh;\n      margin: 0;\n      font-family: Arial, sans-serif;\n      background-color: #f5f7fa;\n      color: #333;\n    }\n\n    .break-container {\n      text-align: center;\n      background: #ffffff;\n      border-radius: 8px;\n      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);\n      padding: 40px;\n      width: 90%;\n      max-width: 400px;\n    }\n\n    h2 {\n      color: #4CAF50;\n      margin-bottom: 10px;\n    }\n\n    #continue {\n      padding: 15px 30px;\n      font-size: 1rem;\n      color: white;\n      background-color: #4CAF50;\n      border: none;\n      border-radius: 5px;\n      cursor: pointer;\n      transition: background-color 0.3s;\n    }\n    #continue:hover {\n      background-color: #45a049;\n    }\n\n    .timer {\n      font-size: 1.5rem;\n      margin-top: 20px;\n      color: #FF5722;\n    }\n  \u003C\u002Fstyle\u003E\n\u003C\u002Fhead\u003E\n\u003Cbody\u003E\n\n\u003Cdiv class=\"break-container\"\u003E\n  \u003Ch2\u003ETake a Break\u003C\u002Fh2\u003E\n  \u003Cp\u003EYou can take a 1-minute break before continuing. Click 'Continue' if you do not want to rest.\u003C\u002Fp\u003E\n  \u003Cbutton id=\"continue\"\u003EContinue\u003C\u002Fbutton\u003E\n  \u003Cdiv class=\"timer\" id=\"timer\"\u003E60\u003C\u002Fdiv\u003E\n\u003C\u002Fdiv\u003E\n\n\u003C\u002Fbody\u003E\n\u003C\u002Fhtml\u003E"
              }
            ],
            "scrollTop": true,
            "submitButtonText": "Continue →continue",
            "submitButtonPosition": "hidden",
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {
              "run": function anonymous(
) {
  let timeLeft = 60;
  const timerDisplay = document.getElementById('timer');
  const continueButton = document.getElementById('continue');

  const countdown = setInterval(() => {
    timeLeft -= 1;
    timerDisplay.textContent = timeLeft;

    if (timeLeft <= 0) {
      clearInterval(countdown);
    }
  }, 1000);

  continueButton.addEventListener('click', () => {
    clearInterval(countdown);
  });

}
            },
            "title": "Break screen",
            "timeout": "60000",
            "skip": "${parameters.counter !== 18}"
          }
        ]
      }
    },
    {
      "type": "lab.html.Screen",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "run": function anonymous(
) {
jatos.submitResultData(window.response, jatos.endStudy);
}
      },
      "title": "Screen - End",
      "content": "\u003Cmain class=\"content-vertical-center content-horizontal-center\"\u003E\r\n\r\n  \u003Cdiv\u003E\r\n    \u003Ch2\u003EThank you for taking part!\u003C\u002Fh2\u003E\r\n    You can close this window now.\r\n  \u003C\u002Fdiv\u003E\r\n\r\n\u003C\u002Fmain\u003E\r\n\r\n\u003Cfooter\u003E\u003C\u002Ffooter\u003E"
    }
  ]
})

// Let's go!
jatos.onLoad(() => study.run())